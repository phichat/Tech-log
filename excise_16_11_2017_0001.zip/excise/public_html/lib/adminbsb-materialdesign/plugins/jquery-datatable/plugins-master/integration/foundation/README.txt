This styling integration has been deprecated and replaced.

The Foundation integration for DataTables has been moved into the core DataTables library and its accompanying extensions to improve the styling integration support and compatibility while making maintenance easier.

Please refer to the DataTables Foundation styling documentation for details on how to use the new styling integration:
	https://datatables.net/manual/styling/foundation